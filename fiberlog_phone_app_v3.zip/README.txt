FiberLog installable Android PWA. On your phone: extract this ZIP, upload all files into a web host root (e.g. a GitHub Pages repository), open the resulting HTTPS link in Chrome, and choose ⋮ > Add to home screen / Install app. App supports offline use after first online load. Data resides only in the browser storage on that phone; backups are essential. Do not publish customer data inside source files. No automatic deadline notifications.

Version 2 includes a Fiber Color Code reference with 24 ribbons and fiber lookup (1–288).
